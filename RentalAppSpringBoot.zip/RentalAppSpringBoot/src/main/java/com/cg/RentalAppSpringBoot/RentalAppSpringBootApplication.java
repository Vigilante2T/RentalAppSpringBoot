package com.cg.RentalAppSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Automatic generated RentalAppSpringBootApplication class which will scan all the components of the given package.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */

@SpringBootApplication
@ComponentScan("com.cg.RentalAppSpringBoot")
public class RentalAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentalAppSpringBootApplication.class, args);
		System.out.println("Welcome to Spring BVoot");
	}

}
