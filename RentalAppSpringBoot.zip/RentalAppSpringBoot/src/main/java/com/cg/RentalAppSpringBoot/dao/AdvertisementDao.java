package com.cg.RentalAppSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.RentalAppSpringBoot.dto.Advertisement;
import com.cg.RentalAppSpringBoot.dto.Agent;

public interface AdvertisementDao extends JpaRepository<Agent, Integer> {
	
	@Query("select ad from Advertisement ad where ad.area = :area")
	public List<Advertisement> findByArea(@Param("area")String area);
	@Query("select ad from Advertisement ad where ad.pincode= :pincode")
	public List<Advertisement> findByPincode(@Param("pincode")long pincode);

}
