package com.cg.RentalAppSpringBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.RentalAppSpringBoot.dto.Advertisement;
import com.cg.RentalAppSpringBoot.dto.Agent;
import com.cg.RentalAppSpringBoot.services.AdvertisementServices;

/**
 * Establishing a Controller file to execute all the opertions in all the classes.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */

@RestController
@RequestMapping("/advertisement")
public class MyControllerr {
	
	@Autowired
	AdvertisementServices adServices;
	
	@RequestMapping(value="/addAd",method= RequestMethod.POST)
	public ResponseEntity<Agent> addProduct(@ModelAttribute Agent ads) {
		
		Agent advertisement = adServices.addAgent(ads);
		if(advertisement == null) {
			return new ResponseEntity("Advertisemetn Not Added",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Agent>(advertisement,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/searchArea",method= RequestMethod.GET)
	public ResponseEntity<List<Advertisement>> searchByArea(@RequestParam("area")String area) {
		
		List<Advertisement> advertisement = adServices.searchByLocation(area);
		if(advertisement.isEmpty()) {
			return new ResponseEntity("Advertisemetn Not found in Database",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Advertisement>>(advertisement,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/searchPincode",method= RequestMethod.GET)
	public ResponseEntity<List<Advertisement>> searchByPincode(@RequestParam("pincode")long pincode) {
		
		List<Advertisement> advertisement = adServices.searchByPincode(pincode);
		if(advertisement.isEmpty()) {
			return new ResponseEntity("Advertisemetn Not found in Database",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Advertisement>>(advertisement,HttpStatus.OK);
		
	}

}
