package com.cg.RentalAppSpringBoot.services;

import java.util.List;

import com.cg.RentalAppSpringBoot.dto.Advertisement;
import com.cg.RentalAppSpringBoot.dto.Agent;



public interface AdvertisementServices {
	
	public Agent addAgent(Agent agent);
//	public Advertisement addAdvertisement(Advertisement ads);
	public List<Advertisement> searchByLocation(String area);
	public List<Advertisement> searchByPincode(long pincode);

}
