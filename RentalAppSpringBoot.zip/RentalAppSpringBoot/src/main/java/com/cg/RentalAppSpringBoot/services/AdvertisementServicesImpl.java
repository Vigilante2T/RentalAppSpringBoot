package com.cg.RentalAppSpringBoot.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.RentalAppSpringBoot.dao.AdvertisementDao;
import com.cg.RentalAppSpringBoot.dto.Advertisement;
import com.cg.RentalAppSpringBoot.dto.Agent;

/**
 * Service Layer implementation.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */

@Service
public class AdvertisementServicesImpl implements AdvertisementServices {
	
	@Autowired
	AdvertisementDao advertisementDao;

	/**
	 * Last modified on  2019-05-25
	 * The following method is used to add a new Agent to the collection.
	 * @return agent
	 */
	
	@Override
	public Agent addAgent(Agent agent) {
		// TODO Auto-generated method stub
		return advertisementDao.save(agent);
	}

	/**
	 * Last modified on  2019-05-25
	 * The following method is used to search advertisement in a particular area.
	 * @param area this string contains area to be searched
	 * @return Advertisement
	 */

	@Override
	public List<Advertisement> searchByLocation(String area) {
		// TODO Auto-generated method stub
		return advertisementDao.findByArea(area);
	}
	
	/**
	 * Last modified on  2019-05-25
	 * The following method is used to search advertisement in a particular pincode.
	 * @param pincode this long pincode area to be searched
	 * @return Advertisement
	 */

	@Override
	public List<Advertisement> searchByPincode(long pincode) {
		// TODO Auto-generated method stub
		return advertisementDao.findByPincode(pincode);
	}

}
