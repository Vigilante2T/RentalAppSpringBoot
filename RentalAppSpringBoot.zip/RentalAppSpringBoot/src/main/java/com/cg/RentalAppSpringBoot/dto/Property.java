package com.cg.RentalAppSpringBoot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Declaring the attributes of property and setting up constructors, getters, setters and toString methods.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */

@Entity
@Table(name="property")
public class Property {
	
	@Id
	@Column(name="property_id")
	private int property_id;
	@Column(name="area")
	private String area;
	@Column(name="pincode")
	private long pincode;
	@Column(name="building_name")
	private String buildingName;
	@Column(name="flat_number")
	private int flatNumber;
	@Column(name="commission")
	private int commission;
	@Column(name="flat_type")
	private String flatType;
	
	public Property() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Property(int property_id, String area, long pincode, String buildingName, int flatNumber, int commission,
			String flatType) {
		super();
		this.property_id = property_id;
		this.area = area;
		this.pincode = pincode;
		this.buildingName = buildingName;
		this.flatNumber = flatNumber;
		this.commission = commission;
		this.flatType = flatType;
	}

	public int getProperty_id() {
		return property_id;
	}

	public void setProperty_id(int property_id) {
		this.property_id = property_id;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public int getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(int flatNumber) {
		this.flatNumber = flatNumber;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	@Override
	public String toString() {
		return "Property [property_id=" + property_id + ", area=" + area + ", pincode=" + pincode + ", buildingName="
				+ buildingName + ", flatNumber=" + flatNumber + ", commission=" + commission + ", flatType=" + flatType
				+ "]";
	}
	
	

}
