package com.cg.RentalAppSpringBoot.dto;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 * Declaring the attributes of agent and setting up constructors, getters, setters and toString methods.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */


@Entity
@Table(name="agent")
public class Agent {
	
	@Id
	@Column(name="phone_number")
	private BigInteger phoneNumber;
	@Column(name="name")
	private String name;
	@OneToMany(cascade= CascadeType.ALL)
	@JoinColumn(name="advertisement_list")
	private List<Advertisement> advertisement;
	
	public Agent() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Agent(BigInteger phoneNumber, String name,
			List<com.cg.RentalAppSpringBoot.dto.Advertisement> advertisement) {
		super();
		this.phoneNumber = phoneNumber;
		this.name = name;
		this.advertisement = advertisement;
	}
	public BigInteger getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(BigInteger phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Advertisement> getAdvertisement() {
		return advertisement;
	}
	public void setAdvertisement(List<Advertisement> advertisement) {
		this.advertisement = advertisement;
	}
	
	@Override
	public String toString() {
		return "Agent [phoneNumber=" + phoneNumber + ", name=" + name + ", advertisement=" + advertisement + "]";
	}
	
	

}
