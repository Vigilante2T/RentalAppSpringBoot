package com.cg.RentalAppSpringBoot.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
/**
 * Declaring the attributes of advertisement and setting up constructors, getters, setters and toString methods.
 * @author yassharm
 * @version 1.0
 * @since 2019-05-25
 */

@Entity
@Table(name="advertisement")
public class Advertisement {
	
	@Id
	@Column(name="advertisement_id")
	private int advertisement_id;
	@Column(name="area")
	private String area;
	@Column(name="pincode")
	private long pincode;
	@Column(name="phoneNumber")
	private BigInteger phoneNumber;
	@Column(name="flat_type")
	private String flatType;
	
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="ad_property")
	private Property property;

	public Advertisement() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Advertisement(int advertisement_id, String area, long pincode, BigInteger phoneNumber, String flatType,
			Property property) {
		super();
		this.advertisement_id = advertisement_id;
		this.area = area;
		this.pincode = pincode;
		this.phoneNumber = phoneNumber;
		this.flatType = flatType;
		this.property = property;
	}

	public int getAdvertisement_id() {
		return advertisement_id;
	}

	public void setAdvertisement_id(int advertisement_id) {
		this.advertisement_id = advertisement_id;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public BigInteger getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(BigInteger phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}

	@Override
	public String toString() {
		return "Advertisement [advertisement_id=" + advertisement_id + ", area=" + area + ", pincode=" + pincode
				+ ", phoneNumber=" + phoneNumber + ", flatType=" + flatType + ", property=" + property + "]";
	}
	
	

}
